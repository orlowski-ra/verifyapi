require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const dns = require('dns');
const net = require('net');
const crypto = require('crypto');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Database setup
const db = new sqlite3.Database('./verifyapi.db');

// Create tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS disposable_domains (
    domain TEXT PRIMARY KEY,
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
  
  db.run(`CREATE TABLE IF NOT EXISTS verification_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT,
    result TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
  
  db.run(`CREATE TABLE IF NOT EXISTS api_keys (
    key TEXT PRIMARY KEY,
    tier TEXT DEFAULT 'free',
    requests_used INTEGER DEFAULT 0,
    requests_limit INTEGER DEFAULT 100,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
  
  // Insert common disposable email domains
  const disposableDomains = [
    'tempmail.com', 'throwaway.com', 'mailinator.com', 'guerrillamail.com',
    '10minutemail.com', 'yopmail.com', 'fakeinbox.com', 'tempinbox.com',
    'sharklasers.com', 'getairmail.com', 'mailnesia.com', 'temp-mail.ru'
  ];
  
  disposableDomains.forEach(domain => {
    db.run('INSERT OR IGNORE INTO disposable_domains (domain) VALUES (?)', [domain]);
  });
});

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: { error: 'Too many requests, please try again later.' }
});
app.use(limiter);

// Email validation regex
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Check if domain is disposable
function isDisposableDomain(domain) {
  return new Promise((resolve, reject) => {
    db.get('SELECT 1 FROM disposable_domains WHERE domain = ?', [domain], (err, row) => {
      if (err) reject(err);
      resolve(!!row);
    });
  });
}

// Verify MX records
function verifyMX(domain) {
  return new Promise((resolve) => {
    dns.resolveMx(domain, (err, addresses) => {
      if (err || !addresses || addresses.length === 0) {
        resolve({ valid: false, reason: 'No MX records found' });
      } else {
        resolve({ valid: true, mx: addresses });
      }
    });
  });
}

// SMTP verification (basic)
function verifySMTP(email, mxRecord) {
  return new Promise((resolve) => {
    // Simplified SMTP check - in production, this would be more robust
    // For now, we'll just check if we can connect to port 25
    const socket = new net.Socket();
    let timeout;
    
    timeout = setTimeout(() => {
      socket.destroy();
      resolve({ valid: false, reason: 'Connection timeout' });
    }, 5000);
    
    socket.connect(25, mxRecord.exchange, () => {
      clearTimeout(timeout);
      socket.destroy();
      resolve({ valid: true });
    });
    
    socket.on('error', () => {
      clearTimeout(timeout);
      resolve({ valid: false, reason: 'Cannot connect to mail server' });
    });
  });
}

// Main verification function
async function verifyEmail(email) {
  const startTime = Date.now();
  
  // Check format
  if (!emailRegex.test(email)) {
    return {
      email,
      valid: false,
      reason: 'Invalid email format',
      checks: { format: false },
      score: 0,
      time: Date.now() - startTime
    };
  }
  
  const [, domain] = email.split('@');
  const checks = { format: true };
  
  // Check disposable
  const isDisposable = await isDisposableDomain(domain);
  checks.disposable = !isDisposable;
  
  if (isDisposable) {
    return {
      email,
      valid: false,
      reason: 'Disposable email address',
      checks,
      score: 20,
      disposable: true,
      time: Date.now() - startTime
    };
  }
  
  // Verify MX
  const mxResult = await verifyMX(domain);
  checks.mx = mxResult.valid;
  
  if (!mxResult.valid) {
    return {
      email,
      valid: false,
      reason: mxResult.reason,
      checks,
      score: 30,
      time: Date.now() - startTime
    };
  }
  
  // Check SMTP (optional, can be slow)
  let smtpResult = { valid: false, skipped: true };
  if (process.env.ENABLE_SMTP_CHECK === 'true') {
    smtpResult = await verifySMTP(email, mxResult.mx[0]);
    checks.smtp = smtpResult.valid;
  }
  
  // Calculate score
  let score = 100;
  if (!checks.format) score -= 100;
  if (!checks.disposable) score -= 40;
  if (!checks.mx) score -= 30;
  if (!checks.smtp) score -= 10;
  
  const result = {
    email,
    valid: score >= 70,
    score,
    checks,
    time: Date.now() - startTime
  };
  
  // Log verification
  db.run('INSERT INTO verification_logs (email, result) VALUES (?, ?)', 
    [email, JSON.stringify(result)]);
  
  return result;
}

// Generate API key
function generateApiKey() {
  return 'va_' + crypto.randomBytes(32).toString('hex');
}

// Routes

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Create API key
app.post('/api/key', async (req, res) => {
  const key = generateApiKey();
  
  db.run('INSERT INTO api_keys (key, tier, requests_limit) VALUES (?, ?, ?)',
    [key, 'free', 100],
    (err) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to create API key' });
      }
      res.json({ 
        key, 
        tier: 'free',
        requests_limit: 100,
        message: 'Keep this key secure. It cannot be retrieved later.'
      });
    }
  );
});

// Verify single email
app.get('/api/verify/:email', async (req, res) => {
  const apiKey = req.headers['x-api-key'];
  
  if (!apiKey) {
    return res.status(401).json({ error: 'API key required' });
  }
  
  // Check API key
  const keyData = await new Promise((resolve) => {
    db.get('SELECT * FROM api_keys WHERE key = ?', [apiKey], (err, row) => {
      resolve(row);
    });
  });
  
  if (!keyData) {
    return res.status(401).json({ error: 'Invalid API key' });
  }
  
  if (keyData.requests_used >= keyData.requests_limit) {
    return res.status(429).json({ 
      error: 'Rate limit exceeded',
      upgrade_url: '/upgrade'
    });
  }
  
  // Update usage
  db.run('UPDATE api_keys SET requests_used = requests_used + 1 WHERE key = ?', [apiKey]);
  
  const { email } = req.params;
  const result = await verifyEmail(email);
  
  res.json({
    ...result,
    usage: {
      used: keyData.requests_used + 1,
      limit: keyData.requests_limit,
      remaining: keyData.requests_limit - (keyData.requests_used + 1)
    }
  });
});

// Verify bulk emails
app.post('/api/verify/bulk', async (req, res) => {
  const apiKey = req.headers['x-api-key'];
  
  if (!apiKey) {
    return res.status(401).json({ error: 'API key required' });
  }
  
  const { emails } = req.body;
  
  if (!Array.isArray(emails) || emails.length === 0) {
    return res.status(400).json({ error: 'Emails array required' });
  }
  
  if (emails.length > 100) {
    return res.status(400).json({ error: 'Maximum 100 emails per request' });
  }
  
  const results = await Promise.all(emails.map(email => verifyEmail(email)));
  
  res.json({
    results,
    summary: {
      total: results.length,
      valid: results.filter(r => r.valid).length,
      invalid: results.filter(r => !r.valid).length
    }
  });
});

// Get usage stats
app.get('/api/stats', async (req, res) => {
  const apiKey = req.headers['x-api-key'];
  
  if (!apiKey) {
    return res.status(401).json({ error: 'API key required' });
  }
  
  const keyData = await new Promise((resolve) => {
    db.get('SELECT * FROM api_keys WHERE key = ?', [apiKey], (err, row) => {
      resolve(row);
    });
  });
  
  if (!keyData) {
    return res.status(401).json({ error: 'Invalid API key' });
  }
  
  // Get last 24h verifications
  const recentVerifications = await new Promise((resolve) => {
    db.all(`
      SELECT COUNT(*) as count 
      FROM verification_logs 
      WHERE created_at > datetime('now', '-1 day')
    `, (err, rows) => {
      resolve(rows?.[0]?.count || 0);
    });
  });
  
  res.json({
    key: apiKey.slice(0, 10) + '...',
    tier: keyData.tier,
    usage: {
      used: keyData.requests_used,
      limit: keyData.requests_limit,
      remaining: keyData.requests_limit - keyData.requests_used
    },
    recent_verifications: recentVerifications,
    created_at: keyData.created_at
  });
});

// Landing page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Pricing page
app.get('/pricing', (req, res) => {
  res.json({
    tiers: [
      {
        name: 'Free',
        price: 0,
        requests: 100,
        features: ['100 verifications/month', 'Basic validation', 'API access']
      },
      {
        name: 'Starter',
        price: 9,
        requests: 10000,
        features: ['10,000 verifications/month', 'MX validation', 'SMTP check', 'Priority support']
      },
      {
        name: 'Pro',
        price: 29,
        requests: 100000,
        features: ['100,000 verifications/month', 'All validations', 'Bulk API', 'Dedicated support', 'Custom integration']
      }
    ]
  });
});

// Documentation
app.get('/docs', (req, res) => {
  res.json({
    name: 'VerifyAPI',
    version: '1.0.0',
    description: 'Email verification API service',
    endpoints: [
      {
        method: 'GET',
        path: '/api/verify/:email',
        description: 'Verify a single email address',
        headers: { 'X-API-Key': 'Your API key' },
        example: 'curl -H "X-API-Key: va_xxx" https://api.verifyapi.com/api/verify/test@example.com'
      },
      {
        method: 'POST',
        path: '/api/verify/bulk',
        description: 'Verify up to 100 emails at once',
        body: { emails: ['test1@example.com', 'test2@example.com'] }
      },
      {
        method: 'GET',
        path: '/api/stats',
        description: 'Get usage statistics'
      }
    ]
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`✅ VerifyAPI running on port ${PORT}`);
  console.log(`📊 API endpoint: http://localhost:${PORT}/api/verify/:email`);
  console.log(`📚 Documentation: http://localhost:${PORT}/docs`);
});

module.exports = app;
